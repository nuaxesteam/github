const pesoFinalInput = document.getElementById("pesoFinal");
const sacosInput = document.getElementById("sacos");
const mineroInput = document.getElementById("minero");
const tenorInput = document.getElementById("tenor");

// Escuchar cambios en PESO FINAL y SACOS
pesoFinalInput.addEventListener("input", calcular);
sacosInput.addEventListener("input", calcular);

function calcular() {
  const pesoFinal = parseFloat(pesoFinalInput.value) || 0;
  const sacos = parseFloat(sacosInput.value) || 0;

  // Fórmulas dinámicas
  const tenor = sacos > 0 ? pesoFinal / sacos : 0;
  const minero = pesoFinal * 0.35;

  tenorInput.value = tenor.toFixed(2);
  mineroInput.value = minero.toFixed(2);
}

// Envío a Gmail
document.getElementById("sendEmailBtn").addEventListener("click", () => {
  const vertical = document.getElementById("vertical").value;
  const molinos = document.getElementById("molinos").value;
  const sacos = sacosInput.value;
  const pesoInicial = document.getElementById("pesoInicial").value;
  const pesoFinal = pesoFinalInput.value;
  const minero = mineroInput.value;
  const tenor = tenorInput.value;
  const autorizado = document.getElementById("autorizado").value;
  const fecha = document.getElementById("fecha").value;

  const cuerpo = `MineroPro Aztgld - Reporte%0D%0A%0D%0A` +
    `VERTICAL: ${vertical}%0D%0A` +
    `MOLINOS: ${molinos}%0D%0A` +
    `SACOS: ${sacos}%0D%0A` +
    `PESO INICIAL: ${pesoInicial}%0D%0A` +
    `PESO FINAL: ${pesoFinal}%0D%0A` +
    `MINERO: ${minero}%0D%0A` +
    `TENOR: ${tenor}%0D%0A%0D%0A` +
    `AUTORIZADO POR: ${autorizado}%0D%0A` +
    `FECHA: ${fecha}`;

  window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=&su=Reporte MineroPro Aztgld&body=${cuerpo}`, '_blank');
});
